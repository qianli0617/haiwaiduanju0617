<?php

return [
    'Site_id'        => '站点ID',
    'Sign'           => '站点标识',
    'Status'         => '状态',
    'Status normal'  => '正常',
    'Status hidden'  => '隐藏',
    'Expiretime'     => '过期时间',
    'Admin.username' => '用户名',
    'Admin.nickname' => '昵称',
    'Admin.mobile' => '手机号',
    'Email' => '邮箱',
    'Is default' => '是否默认',
    'Are you sure you want to delete this item?' => '确认要删除吗？如果你已对此站点授权过小程序，后续请重新授权小程序。',
    'Regular site' => '普通站点',
    'Default Site' => '默认站点',
    'Default site prohibits deletion!' => '默认站点禁止删除！',
    'Please set at least one default site!' => '请至少设置一个默认站点！',
    'The default site is your main site, and there will be no parameters in the domain URL.' => '默认站点是您的主站，域名URL里不会带参数。',
];
