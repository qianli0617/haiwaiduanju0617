<?php

return [
    'Vid'         => '短剧',
    'Name'        => '壁纸名称',
    'Image'       => '壁纸图片',
    'Views'       => '浏览量',
    'Downloads'   => '下载量',
    'Video.title' => '标题'
];
