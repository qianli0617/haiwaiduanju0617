<?php

return [
    'Type'          => '类型',
    'Type log'      => '记录',
    'Set type to log'=> '设为记录',
    'Type favorite' => '追剧',
    'Set type to favorite'=> '设为追剧',
    'User_id'       => '用户',
    'Vid'           => '短剧',
    'Episode_id'    => '剧集',
    'View_time'     => '观看时间',
    'Video.title'   => '标题',
    'User.nickname' => '昵称'
];
