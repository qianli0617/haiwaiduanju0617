<?php

return [
    'Id'            => 'ID',
    'Oldversion'    => '旧版本号',
    'Newversion'    => '新版本号',
    'Packagesize'   => '包大小',
    'Content'       => '升级内容',
    'Downloadurl'   => '下载地址',
    'Enforce'       => '强制更新',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏'
];
