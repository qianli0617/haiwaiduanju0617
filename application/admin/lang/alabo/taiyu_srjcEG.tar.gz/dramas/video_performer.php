<?php

return [
    'Vid'            => '短剧',
    'Type'           => '类型',
    'Type director'  => '导演',
    'Type performer' => '演员',
    'Name'           => '姓名',
    'En_name'        => '英文名',
    'Avatar'         => '头像',
    'Tags'           => '标签',
    'Play'           => '饰演',
    'Profile'        => '简介',
    'Video.title'    => '标题'
];
