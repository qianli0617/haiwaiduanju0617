<?php

return [
    'Title'         => '任务标题',
    'Desc'          => '任务描述',
    'Hook'          => '事件',
    'Type'          => '任务类型',
    'Type first'    => '首次',
    'Type day'      => '每天',
    'Limit'         => '限制次数',
    'Usable'        => '奖励剧场积分',
    'Status'        => '状态',
    'Status normal' => '启用',
    'Status hidden' => '隐藏',
    'User register after' => '新用户首次注册后',
    'Share success' => '分享成功后(新用户注册)',
];
