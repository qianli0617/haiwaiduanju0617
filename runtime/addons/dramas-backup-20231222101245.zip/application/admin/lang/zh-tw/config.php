<?php
                    
return [
    'name' => '變數名稱',
    'intro' => '描述',
    'group' => '分組',
    'type' => '類型',
    'value' => '變數值'
];
