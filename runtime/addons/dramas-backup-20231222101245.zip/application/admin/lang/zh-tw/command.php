<?php
                    
return [
    'Id' => 'ID',
    'Type' => '類型',
    'Params' => '參數',
    'Command' => '命令',
    'Content' => '返回結果',
    'Executetime' => '執行時間',
    'Execute again' => '再次執行',
    'Successed' => '成功',
    'Failured' => '失敗'
];
