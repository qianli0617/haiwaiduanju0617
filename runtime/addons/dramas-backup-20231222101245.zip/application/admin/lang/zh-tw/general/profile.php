<?php
                    
return [
    'Url' => '鏈接',
    'Userame' => '用戶名',
    'Click to edit' => '點擊編輯',
    'Admin log' => '操作日誌',
    'Leave password blank if dont want to change' => '不修改密碼請留空',
    'Please input correct email' => '請輸入正確的Email地址',
    'Please input correct password' => '密碼長度必須在6-30比特之間，不能包含空格',
    'Password must be 6 to 30 characters' => '密碼長度必須在6-30比特之間，不能包含空格',
    'Email already exists' => '郵箱已經存在'
];
