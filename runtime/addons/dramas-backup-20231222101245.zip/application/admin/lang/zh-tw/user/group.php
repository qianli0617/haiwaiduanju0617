<?php
                    
return [
    'Name' => '組名',
    'Rules' => '許可權節點',
    'Change password' => '修改密碼'
];
