<?php
                    
return [
    'Pid' => '父ID',
    'Name' => '規則',
    'Title' => '標題',
    'Remark' => '備註',
    'Ismenu' => '是否選單',
    'Change password' => '修改密碼',
    'Menu tips' => '規則任意，請不可重複，僅做層級顯示，無需匹配控制器和方法',
    'Node tips' => '模塊/控制器/方法名',
    'Toggle all' => '顯示全部',
    'Toggle menu visible' => '點擊切換選單顯示',
    'Toggle sub menu' => '點擊切換子功能表'
];
