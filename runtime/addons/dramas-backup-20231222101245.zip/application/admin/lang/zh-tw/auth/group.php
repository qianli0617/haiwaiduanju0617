<?php
                    
return [
    'The parent group can not be its own child' => '父組別不能是自身的子組別',
    'The parent group can not found' => '父組別未找到',
    'Group not found' => '組別未找到',
    'Can not change the parent to child' => '父組別不能是它的子組別',
    'Can not change the parent to self' => '父組別不能是它自己',
    'You can not delete group that contain child group and administrators' => '你不能删除含有子組和管理員的組',
    'The parent group exceeds permission limit' => '父組別超出許可權範圍',
    'The parent group can not be its own child or itself' => '父組別不能是它的子組別及本身'
];
