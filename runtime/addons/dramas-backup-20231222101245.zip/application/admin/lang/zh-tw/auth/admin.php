<?php
                    
return [
    'Email' => '電子郵箱',
    'Mobile' => '手機號',
    'Group' => '所屬組別',
    'Loginfailure' => '登入失敗次數',
    'Login time' => '最後登錄',
    'The parent group exceeds permission limit' => '父組別超出許可權範圍',
    'Please input correct username' => '用戶名只能由3-30比特數位、字母、底線組合',
    'Username must be 3 to 30 characters' => '用戶名只能由3-30比特數位、字母、底線組合',
    'Please input correct password' => '密碼長度必須在6-30比特之間，不能包含空格',
    'Password must be 6 to 30 characters' => '密碼長度必須在6-30比特之間，不能包含空格'
];
