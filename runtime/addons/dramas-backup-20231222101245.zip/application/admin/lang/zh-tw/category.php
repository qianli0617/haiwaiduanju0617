<?php
                    
return [
    'Id' => 'ID',
    'Pid' => '父ID',
    'Type' => '類型',
    'All' => '全部',
    'Image' => '圖片',
    'Keywords' => '關鍵字',
    'Description' => '描述',
    'Diyname' => '自定義名稱',
    'Category warmtips' => '溫馨提示：欄目類型請前往常規管理->系統配寘->字典配寘中進行管理',
    'Can not change the parent to child or itself' => '父組別不能是它的子組別或它自己'
];
