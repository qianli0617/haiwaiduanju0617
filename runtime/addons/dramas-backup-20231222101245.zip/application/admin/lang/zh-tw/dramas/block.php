<?php
                    
return [
    'Type' => '類型',
    'Type focus' => '焦點圖',
    'Type side' => '廣告圖',
    'Name' => '名稱',
    'Title' => '標題',
    'Image' => '圖片',
    'Url' => '鏈接',
    'Parsetpl' => '連結類型',
    'Parsetpl 0' => '外部',
    'Parsetpl 1' => '內部',
    'Status normal' => '顯示',
    'Status hidden' => '隱藏'
];
