<?php
                    
return [
    'Title' => '任務標題',
    'Desc' => '任務描述',
    'Hook' => '事件',
    'Type' => '任務類型',
    'Type first' => '首次',
    'Type day' => '每天',
    'Limit' => '限制次數',
    'Usable' => '獎勵劇場積分',
    'Status' => '狀態',
    'Status normal' => '啟用',
    'Status hidden' => '隱藏',
    'User register after' => '新用戶首次注册後',
    'Share success' => '分享成功後（新用戶註冊）'
];
