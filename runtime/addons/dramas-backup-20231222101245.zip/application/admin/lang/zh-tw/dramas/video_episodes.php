<?php
                    
return [
    'Vid' => '短劇',
    'Name' => '名稱',
    'Image' => '封面',
    'Video' => '視頻',
    'Duration' => '時長',
    'Price' => '價格',
    'Vprice' => 'VIP價格',
    'Sales' => '銷量',
    'Likes' => '點贊量',
    'Views' => '播放量',
    'Status' => '商品狀態',
    'Status normal' => '顯示',
    'Set status to normal' => '設為顯示',
    'Status hidden' => '隱藏',
    'Set status to hidden' => '設為隱藏',
    'Video.title' => '標題'
];
