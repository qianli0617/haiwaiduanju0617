<?php
                    
return [
    'Vid' => '短劇',
    'Type' => '類型',
    'Type director' => '導演',
    'Type performer' => '演員',
    'Name' => '姓名',
    'En_name' => '英文名',
    'Avatar' => '頭像',
    'Tags' => '標籤',
    'Play' => '飾演',
    'Profile' => '簡介',
    'Video.title' => '標題'
];
