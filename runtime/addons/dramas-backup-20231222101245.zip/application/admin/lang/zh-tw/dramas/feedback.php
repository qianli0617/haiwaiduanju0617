<?php
                    
return [
    'User_id' => '迴響用戶',
    'Type' => '迴響類型',
    'Content' => '迴響內容',
    'Images' => '圖片',
    'Phone' => '聯繫電話',
    'Status' => '是否處理',
    'Status 0' => '未處理',
    'Status 1' => '已處理',
    'Remark' => '處理備註',
    'User.nickname' => '昵稱'
];
