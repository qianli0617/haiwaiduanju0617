<?php
                    
return [
    'Lang_id' => '語言',
    'Type' => '充值類型',
    'Day' => '天',
    'Month' => '月',
    'Quarter' => '季',
    'Year' => '年',
    'Title' => '標題',
    'Desc' => '描述',
    'Content' => '權益',
    'Price' => '價格',
    'First_price' => '首沖價格',
    'Original_price' => '劃線價格',
    'Num' => '充值數量',
    'Status' => '是否啟用',
    'Status 0' => '不啟用',
    'Status 1' => '啟用'
];
