<?php
                    
return [
    'Lang_id' => '語言',
    'Title' => '標題',
    'Content' => '內容',
    'After configuring the protocol for the first time, remember to check it in [Setting ->Configuration ->Basic ->System], otherwise it will not take effect.' => '第一次配寘完協定之後，記得去【配寘->系統配寘->基礎配寘->系統資訊】裏進行勾選，否則不生效的。'
];
