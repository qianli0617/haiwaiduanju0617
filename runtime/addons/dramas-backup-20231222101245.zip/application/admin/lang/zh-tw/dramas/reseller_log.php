<?php
                    
return [
    'Type' => '類型',
    'Type direct' => '直接傭金',
    'Type indirect' => '間接傭金',
    'Reseller_user_id' => '分銷商ID',
    'User_id' => '用戶ID',
    'Pay_money' => '支付金額',
    'Ratio' => '分潤比例',
    'Money' => '傭金',
    'Memo' => '備註',
    'Order_type' => '訂單類型',
    'Order_type vip' => 'VIP訂單',
    'Order_type reseller' => '分銷商訂單',
    'Order_type usable' => '劇場積分充值訂單',
    'Order_id' => '訂單ID',
    'User.nickname' => '用戶昵稱',
    'Reseller.nickname' => '分銷商昵稱'
];
