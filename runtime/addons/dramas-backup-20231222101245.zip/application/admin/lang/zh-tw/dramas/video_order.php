<?php
                    
return [
    'Vid' => '短劇',
    'Episode_id' => '劇集',
    'Order_sn' => '訂單號',
    'User_id' => '用戶',
    'Total_fee' => '支付積分',
    'Platform' => '平臺',
    'Platform h5' => 'H5',
    'Set platform to h5' => '設為H5',
    'Platform app' => 'App',
    'Set platform to app' => '設為App',
    'Video.title' => '短劇標題',
    'Episodes.name' => '劇集名稱'
];
