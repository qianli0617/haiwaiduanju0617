<?php
                    
return [
    'Lang_id' => '語言',
    'Title' => '標題',
    'Image' => '圖片',
    'Flag' => '標識',
    'Desc' => '描述',
    'Content' => '權益',
    'Usable' => '套餐總積分',
    'Original_usable' => '套餐基礎積分',
    'Give_usable' => '套餐贈送積分',
    'Price' => '價格',
    'Give_price' => '贈送金額',
    'First_price' => '首沖價格',
    'Original_price' => '劃線價格',
    'Status' => '是否啟用',
    'Status 0' => '不啟用',
    'Status 1' => '啟用'
];
