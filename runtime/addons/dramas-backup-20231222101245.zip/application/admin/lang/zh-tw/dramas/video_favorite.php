<?php
                    
return [
    'Type' => '類型',
    'Type like' => '點贊',
    'Set type to like' => '設為點贊',
    'Type favorite' => '收藏',
    'Set type to favorite' => '設為收藏',
    'User_id' => '用戶',
    'Vid' => '短劇',
    'Episode_id' => '劇集',
    'Video.title' => '標題',
    'User.nickname' => '昵稱'
];
