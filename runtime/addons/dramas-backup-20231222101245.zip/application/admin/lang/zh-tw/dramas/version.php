<?php
                    
return [
    'Id' => 'ID',
    'Oldversion' => '舊版本號',
    'Newversion' => '新版本號',
    'Packagesize' => '包大小',
    'Content' => '陞級內容',
    'Downloadurl' => '下載地址',
    'Enforce' => '強制更新',
    'Status' => '狀態',
    'Status normal' => '正常',
    'Set status to normal' => '設為正常',
    'Status hidden' => '隱藏',
    'Set status to hidden' => '設為隱藏'
];
