<?php
                    
return [
    'Type' => '類型',
    'Type log' => '記錄',
    'Set type to log' => '設為記錄',
    'Type favorite' => '追劇',
    'Set type to favorite' => '設為追劇',
    'User_id' => '用戶',
    'Vid' => '短劇',
    'Episode_id' => '劇集',
    'View_time' => '觀看時間',
    'Video.title' => '標題',
    'User.nickname' => '昵稱'
];
