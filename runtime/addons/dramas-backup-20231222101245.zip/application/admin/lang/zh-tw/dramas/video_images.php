<?php
                    
return [
    'Vid' => '短劇',
    'Name' => '壁紙名稱',
    'Image' => '壁紙圖片',
    'Views' => '流覽量',
    'Downloads' => '下載量',
    'Video.title' => '標題'
];
