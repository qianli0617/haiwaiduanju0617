<?php
                    
return [
    'Lang_id' => '語言',
    'Name' => '分銷商',
    'Level' => '等級',
    'Image' => '圖片',
    'Price' => '價格',
    'Original_price' => '原價',
    'Direct' => '直接分潤',
    'Indirect' => '間接分潤',
    'Expire' => '有效期',
    'Status normal' => '顯示',
    'Status hidden' => '隱藏',
    'Forever' => '永久',
    'Year' => '年',
    'Month' => '月',
    'Day' => '天',
    'Please select the unit before entering the validity period' => '輸入有效期前請先選擇組織',
    'First distribution ratio (percentage)' => '一級分銷比例（百分比）',
    'Secondary distribution ratio (percentage)' => '二級分銷比例（百分比）'
];
