<?php
                    
return [
    'Site_id' => '網站ID',
    'Sign' => '網站標識',
    'Status' => '狀態',
    'Status normal' => '正常',
    'Status hidden' => '隱藏',
    'Expiretime' => '過期時間',
    'Admin.username' => '用戶名',
    'Admin.nickname' => '昵稱',
    'Admin.mobile' => '手機號',
    'Email' => '郵箱',
    'Is default' => '是否默認',
    'Are you sure you want to delete this item?' => '確認要删除嗎？ 如果你已對此網站授權過小程式，後續請重新授權小程式。',
    'Regular site' => '普通網站',
    'Default Site' => '默認網站',
    'Default site prohibits deletion!' => '默認網站禁止删除！',
    'Please set at least one default site!' => '請至少設定一個默認網站！',
    'The default site is your main site, and there will be no parameters in the domain URL.' => '默認網站是您的主站，功能變數名稱URL裏不會帶參數。'
];
