<?php

return [
    'Type'                => '类型',
    'Type direct'         => '直接佣金',
    'Type indirect'       => '间接佣金',
    'Reseller_user_id'    => '分销商ID',
    'User_id'             => '用户ID',
    'Pay_money'           => '支付金额',
    'Ratio'               => '分润比例',
    'Money'               => '佣金',
    'Memo'                => '备注',
    'Order_type'          => '订单类型',
    'Order_type vip'      => 'VIP订单',
    'Order_type reseller' => '分销商订单',
    'Order_type usable'   => '剧场积分充值订单',
    'Order_id'            => '订单ID',
    'User.nickname'       => '用户昵称',
    'Reseller.nickname'   => '分销商昵称',
];
