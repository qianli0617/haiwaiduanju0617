<?php

return [
    'Title'      => '标题',
    'Content'    => '内容',
    'After configuring the protocol for the first time, remember to check it in [Setting ->Configuration ->Basic ->System], otherwise it will not take effect.' => '第一次配置完协议之后，记得去【配置->系统配置->基础配置->系统信息】里进行勾选，否则不生效的。',
];
