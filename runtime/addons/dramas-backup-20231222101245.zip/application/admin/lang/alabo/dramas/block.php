<?php

return [
    'Type'          => '类型',
    'Type focus'    => '焦点图',
    'Type side'     => '广告图',
    'Name'          => '名称',
    'Title'         => '标题',
    'Image'         => '图片',
    'Url'           => '链接',
    'Parsetpl'      => '链接类型',
    'Parsetpl 0'    => '外部',
    'Parsetpl 1'    => '内部',
    'Status normal' => '显示',
    'Status hidden' => '隐藏'
];
