<?php

return [
    'Vid'           => '短剧',
    'Name'          => '名称',
    'Image'         => '封面',
    'Video'         => '视频',
    'Duration'      => '时长',
    'Price'         => '价格',
    'Vprice'        => 'VIP价格',
    'Sales'         => '销量',
    'Likes'         => '点赞量',
    'Views'         => '播放量',
    'Status'        => '商品状态',
    'Status normal' => '显示',
    'Set status to normal'=> '设为显示',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Video.title'   => '标题'
];
