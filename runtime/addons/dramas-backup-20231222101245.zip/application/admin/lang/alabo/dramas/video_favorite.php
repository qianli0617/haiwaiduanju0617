<?php

return [
    'Type'          => '类型',
    'Type like'     => '点赞',
    'Set type to like'=> '设为点赞',
    'Type favorite' => '收藏',
    'Set type to favorite'=> '设为收藏',
    'User_id'       => '用户',
    'Vid'           => '短剧',
    'Episode_id'    => '剧集',
    'Video.title'   => '标题',
    'User.nickname' => '昵称'
];
