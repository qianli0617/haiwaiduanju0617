<?php

return [
    'Name'            => '组名',
    'Rules'           => '权限节点',
    'Change password' => '修改密码',
];
