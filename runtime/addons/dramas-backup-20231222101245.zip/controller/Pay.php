<?php
/*
  开发作者：南阳迈特网络科技有限公司
  QQ:794929988
*/

namespace addons\dramas\controller;

use addons\dramas\model\ResellerOrder;
use addons\dramas\model\UsableOrder;
use addons\dramas\model\User;
use addons\dramas\model\VipOrder;
use Omnipay\Omnipay;
use think\Log;
use Yansongda\Pay\Exceptions\GatewayException;

/**
 * 支付
 * Class Pay
 * @package addons\dramas\controller
 */
class Pay extends Base
{

    protected $noNeedLogin = ['notifyx', 'notify_paypal', 'notifyr', 'confirm'];
    protected $noNeedRight = ['*'];


    /**
     * 支付宝网页支付
     * @ApiInternal
     */
    public function alipay()
    {
        $order_sn = $this->request->get('order_sn');
        $platform = $this->request->get('platform');

        list($order, $prepay_type) = $this->getOrderInstance($order_sn);
        $order = $order->where('order_sn', $order_sn)->where('site_id', $this->site_id)->find();

        try {
            if (!$order) {
                throw new \Exception(__('Order does not exist'));
            }
            if ($order->status > 0) {
                throw new \Exception(__('Order has payment'));
            }
            if ($order->status < 0) {
                throw new \Exception(__('Order has expired'));
            }

            $order_data = [
                'order_id' => $order->id,
                'out_trade_no' => $order->order_sn,
                'total_fee' => $order->total_fee,
                'subject' => __('Order payment'),
            ];

            $notify_url = $this->request->root(true) . '/addons/dramas/pay/notifyx/payment/alipay/platform/H5/sign/'.$this->sign;
            $pay = new \addons\dramas\library\PayService($this->site_id, 'alipay', 'url', $notify_url);
            $result = $pay->create($order_data);

            $result = $result->getContent();

	        echo $result;
        } catch (\Exception $e) {
            echo $e->getMessage();
        }

        // $this->assign('result', $result);

        // return $this->view->fetch();
    }

    /**
     * PayPal支付
     * @ApiMethod   (POST)
     * @ApiParams   (name="order_sn", type="string", required=true, description="订单号")
     * @ApiParams   (name="payment", type="string", required=true, description="支付平台默认:paypal")
     * @ApiParams   (name="platform", type="string", required=true, description="平台:H5/App")
     * @ApiParams   (name="cancel_url", type="string", required=true, description="跳转地址")
     * @ApiParams   (name="return_url", type="string", required=true, description="跳转地址")
     */
    public function paypal(){
        $user = User::info();
        $order_sn = $this->request->post('order_sn', '');
        $payment = $this->request->post('payment', 'paypal');
        $platform = $this->request->post('platform', 'H5');
        $cancel_url = $this->request->post('cancel_url', '');
        $return_url = $this->request->post('return_url', '');

        list($order, $prepay_type) = $this->getOrderInstance($order_sn);
        $order = $order->where('user_id', $user->id)->where('order_sn', $order_sn)->where('site_id', $this->site_id)->find();

        if (!$order) {
            $this->error(__('Order does not exist'));
        }

        if ($order->status != 0) {
            $this->error(__('Order has expired'));
        }

        if (!$payment || !in_array($payment, ['wechat', 'alipay', 'paypal', 'wallet'])) {
            $this->error(__('Payment type error'));
        }

        $paymentConfig = @json_decode(\addons\dramas\model\Config::get(['name' => 'paypal', 'site_id'=>$this->site_id])->value, true);
        if(empty($paymentConfig)){
            $this->error(__('Please configure PayPal payment first'));
        }
        if(!in_array($platform, $paymentConfig['platform'])){
            $this->error(__('Currently not supported for payment on the current platform'));
        }

        $postData = [
            'amount' => $order->total_fee,
            'currency' => 'USD',
        ];

        if($prepay_type == 'reseller'){
            $reseller = \addons\dramas\model\Reseller::get($order['reseller_id']);
            $postData['description'] = __("Buy:%s", $reseller['name']);
        }elseif($prepay_type == 'vip'){
            $vip = \addons\dramas\model\Vip::get($order['vip_id']);
            $postData['description'] = __("Buy:%s", $vip['title']);
        }else{
            $usable = \addons\dramas\model\Usable::get($order['usable_id']);
            $postData['description'] = __("Buy:%s", $usable['title']);
        }
        $gateway = Omnipay::create('PayPal_Rest');
        $gateway->setClientId($paymentConfig['clent_id']);
        $gateway->setSecret($paymentConfig['client_secret']);
        $mode = $paymentConfig['environment'] == 'sandbox' ? true : false;
        $gateway->setTestMode($mode); //设置为测试环境，如果是生产环境，请设置为false

        $notify_url = $this->request->root(true) . '/addons/dramas/pay/notify_paypal/sign/' . $this->sign;
        $postData['returnUrl'] = $this->request->root(true) . '/h5?' . $this->sign . '#' . $return_url . '?';
        $postData['cancelUrl'] = $this->request->root(true) . '/h5?' . $this->sign . '#' . $cancel_url . '?';
        $postData['notifyUrl'] = $notify_url;
        $response = $gateway->purchase($postData)->setTransactionId($order->order_sn)->send();

        if ($response->isRedirect()) {
            $result = $response->getData(); // 这将包含您需要的付款信息
            if($platform == 'App'){
                $pay_data['amount'] = $order->total_fee;
                $pay_data['currency'] = 'USD';
                $pay_data['clientId'] = $paymentConfig['clent_id'];
                $pay_data['orderId'] = $result['id'];
                $pay_data['environment'] = $paymentConfig['environment']; // 运行环境 sandbox / live
                $pay_data["userAction"] = "continue"; // 按钮 paynow(立即付款) / continue(继续)
                return $this->success(__('Successfully obtained advance payment'), ['pay_data' => $pay_data]);
            }

            // $redirectUrl = $response->getRedirectUrl();
            // 重定向到支付页面
            // $response->redirect();
            return $this->success(__('Successfully obtained advance payment'), ['pay_data' => $result]);
        } else {
            // 显示错误信息
            $this->error(__('Payment error:%s', [$response->getMessage()]));
        }
    }

    /**
     * 拉起支付
     * @ApiMethod   (POST)
     * @ApiParams   (name="order_sn", type="string", required=true, description="订单号")
     * @ApiParams   (name="payment", type="string", required=true, description="支付平台默认wechat")
     * @ApiParams   (name="openid", type="string", required=true, description="微信openid")
     * @ApiParams   (name="platform", type="string", required=true, description="平台:wxMiniProgram=微信小程序")
     */
    public function prepay()
    {
        if (!class_exists(\Yansongda\Pay\Pay::class)) {
            new \addons\dramas\exception\Exception(__('Please configure the payment plugin first'));
        }

        $user = User::info();
        $order_sn = $this->request->post('order_sn');
        $payment = $this->request->post('payment', 'wallet');
        $openid = $this->request->post('openid', '');
        $platform = $this->request->post('platform');

        list($order, $prepay_type) = $this->getOrderInstance($order_sn);
        $order = $order->where('user_id', $user->id)->where('order_sn', $order_sn)->where('site_id', $this->site_id)->find();
        
        if (!$order) {
            $this->error(__('Order does not exist'));
        }

        if ($order->status != 0) {
            $this->error(__('Order has expired'));
        }

        if (!$payment || !in_array($payment, ['wechat', 'alipay', 'wallet'])) {
            $this->error(__('Payment type cannot be empty'));
        }

        if ($payment == 'wallet' && $prepay_type == 'order') {
            // 余额支付
            $this->walletPay($order, $payment, $platform);
        }

        $order_data = [
            'order_id' => $order->id,
            'out_trade_no' => $order->order_sn,
            'total_fee' => $order->total_fee,
        ];

        // 微信公众号，小程序支付，必须有 openid
        if ($payment == 'wechat') {
            if (in_array($platform, ['wxOfficialAccount', 'wxMiniProgram'])) {
                if (isset($openid) && $openid) {
                    // 如果传的有 openid
                    $order_data['openid'] = $openid;
                } else {
                    // 没有 openid 默认拿下单人的 openid
                    $oauth = \addons\dramas\model\UserOauth::where([
                        'user_id' => $order->user_id,
                        'provider' => 'Wechat',
                        'platform' => $platform
                    ])->find();

                    $order_data['openid'] = $oauth ? $oauth->openid : '';
                }
    
                if (empty($order_data['openid'])) {
                    // 缺少 openid
                    return $this->success(__('Missing openid'), 'no_openid');
                }
            }

            $order_data['body'] = __('Order payment');
        } else {
            $order_data['subject'] = __('Order payment');
        }

        try {
            $notify_url = $this->request->root(true) . '/addons/dramas/pay/notifyx/payment/' . $payment . '/platform/' . $platform . '/sign/' . $this->sign;
            $pay = new \addons\dramas\library\PayService($this->site_id, $payment, $platform, $notify_url);
            $result = $pay->create($order_data);
        } catch (\Exception $e) {
            $this->error(__("Payment configuration error:%s", $e->getMessage()));
        }
        
        if ($platform == 'Web') {
            $result = $result->code_url;
        }
        if ($platform == 'H5' && $payment == 'wechat') {
            $result = $result->getContent();
        }

        return $this->success(__('Successfully obtained advance payment'), [
            'pay_data' => $result,
        ]);
    }

    /**
     * 查询支付结果
     * @ApiMethod   (POST)
     * @ApiParams   (name="payment", type="string", required=true, description="支付平台默认wechat")
     * @ApiParams   (name="orderid", type="string", required=true, description="订单编号")
     */
    public function checkPay(){
        $payment = $this->request->post('payment', 'wechat');
        $orderid = $this->request->post("orderid", '');
        if (!$payment || !in_array($payment, ['wechat', 'alipay'])) {
            $this->error(__('Payment type cannot be empty'));
        }
        //发起PC支付(Scan支付)(PC扫码模式)
        $pay = new \addons\dramas\library\PayService($this->site_id, $payment, 'Web');
        try {
            $result = $pay->checkPay($orderid, 'scan');
            if ($result) {
                $this->success("", $result);
            } else {
                $this->error(__('Operation failed'));
            }
        } catch (GatewayException $e) {
            $this->error(__('Operation failed'));
        }
    }

    /**
     * 余额支付
     * @ApiInternal
     * @param $order
     * @param $type
     * @param $method
     */
    public function walletPay ($order, $type, $method) {
        // $order = Db::transaction(function () use ($order, $type, $method) {
        //     // 重新加锁读，防止连点问题
        //     $order = Order::nopay()->where('order_sn', $order->order_sn)->lock(true)->find();
        //     if (!$order) {
        //         $this->error("订单已支付");
        //     }
        //     $total_fee = $order->total_fee;
        //
        //     // 扣除余额
        //     $user = User::info();
        //
        //     if (is_null($user)) {
        //         // 没有登录，请登录
        //         $this->error(__('Please login first'), null, 401);
        //     }
        //
        //     User::money(-$total_fee, $user->id, 'wallet_pay', $order->id, '',[
        //         'order_id' => $order->id,
        //         'order_sn' => $order->order_sn,
        //     ]);
        //
        //     // 支付后流程
        //     $notify = [
        //         'order_sn' => $order['order_sn'],
        //         'transaction_id' => '',
        //         'notify_time' => date('Y-m-d H:i:s'),
        //         'buyer_email' => $user->id,
        //         'pay_fee' => $order->total_fee,
        //         'pay_type' => 'wallet'             // 支付方式
        //     ];
        //     $notify['payment_json'] = json_encode($notify);
        //     $order->paymentProcess($order, $notify);
        //
        //     return $order;
        // });

        $this->success(__('Operation completed'), $order);
    }

    /**
     * 支付成功回调
     * @ApiInternal
     */
    public function notifyx()
    {
        Log::write('notifyx-comein:');

        $payment = $this->request->param('payment', 'wechat');
        $platform = $this->request->param('platform', 'wxMiniProgram');

        $pay = new \addons\dramas\library\PayService($this->site_id, $payment, $platform);

        $result = $pay->notify(function ($data, $pay = null) use ($payment) {
            Log::write('notifyx-result:'. json_encode($data));
            try {
                $out_trade_no = $data['out_trade_no'];
                $out_refund_no = $data['out_biz_no'] ?? '';

                list($order, $prepay_type) = $this->getOrderInstance($out_trade_no);
                // 判断是否是支付宝退款（支付宝退款成功会通知该接口）
                if ($payment == 'alipay'    // 支付宝支付
                    && $data['notify_type'] == 'trade_status_sync'      // 同步交易状态
                    && $data['trade_status'] == 'TRADE_CLOSED'          // 交易关闭
                    && $out_refund_no                                   // 退款单号
                ) {
                    // 退款回调
                    if ($prepay_type == 'order') {
                        // 退款逻辑
                    } else {
                        // 其他订单如果支持退款，逻辑这里补充
                    }

                    return $this->payResponse($pay, $payment);
                }

                // 判断支付宝微信是否是支付成功状态，如果不是，直接返回响应
                if ($payment == 'alipay' && $data['trade_status'] != 'TRADE_SUCCESS') {
                    // 不是交易成功的通知，直接返回成功
                    return $this->payResponse($pay, $payment);
                }

                if ($payment == 'wechat' && ($data['result_code'] != 'SUCCESS' || $data['return_code'] != 'SUCCESS')) {
                    // 微信交易未成功，返回 false，让微信再次通知
                    return false;
                }

                // 支付成功流程
                $pay_fee = $payment == 'alipay' ? $data['total_amount'] : $data['total_fee'] / 100;


                //你可以在此编写订单逻辑
                $order = $order->where('order_sn', $out_trade_no)->find();

                if (!$order || $order->status > 0) {
                    // 订单不存在，或者订单已支付
                    return $this->payResponse($pay, $payment);
                }

                $notify = [
                    'order_sn' => $data['out_trade_no'],
                    'transaction_id' => $payment == 'alipay' ? $data['trade_no'] : $data['transaction_id'],
                    'notify_time' => date('Y-m-d H:i:s', strtotime($data['time_end'] ?? $data['notify_time'])),
                    'buyer_email' => $payment == 'alipay' ? $data['buyer_logon_id'] : $data['openid'],
                    'payment_json' => json_encode($data),
                    'pay_fee' => $pay_fee,
                    'pay_type' => $payment              // 支付方式
                ];
                $order->paymentProcess($order, $notify);

                return $this->payResponse($pay, $payment);
            } catch (\Exception $e) {
                Log::write('notifyx-error:' . json_encode($e->getMessage()));
            }
        });

        return $result;
    }

    /**
     * 支付成功回调
     * @ApiInternal
     */
    public function notify_paypal()
    {
        // 获取支付回调数据
        $data = $this->request->param();
        Log::write('notify-paypal-result:'. json_encode($data));
//        $data = '{"id":"WH-7UH38673AN050531U-0WW4519142280404K","event_version":"1.0","create_time":"2023-12-07T06:29:24.301Z","resource_type":"payment","event_type":"PAYMENTS.PAYMENT.CREATED","summary":"Checkout payment is created and approved by buyer","resource":{"update_time":"2023-12-07T06:29:24Z","create_time":"2023-12-07T06:28:46Z","redirect_urls":{"return_url":"https:\/\/video.nymaite.cn\/h5?edum#\/pages\/home\/user?&amp;paymentId=PAYID-MVYWMHQ07G11202PE512601K","cancel_url":"https:\/\/video.nymaite.cn\/h5?edum#\/pages\/home\/user?"},"links":[{"href":"https:\/\/api.sandbox.paypal.com\/v1\/payments\/payment\/PAYID-MVYWMHQ07G11202PE512601K","rel":"self","method":"GET"},{"href":"https:\/\/api.sandbox.paypal.com\/v1\/payments\/payment\/PAYID-MVYWMHQ07G11202PE512601K\/execute","rel":"execute","method":"POST"},{"href":"https:\/\/www.sandbox.paypal.com\/cgi-bin\/webscr?cmd=_express-checkout&amp;token=EC-1UG11034P27209626","rel":"approval_url","method":"REDIRECT"}],"id":"PAYID-MVYWMHQ07G11202PE512601K","state":"created","transactions":[{"amount":{"total":"0.01","currency":"USD"},"payee":{"merchant_id":"4HQ8R7HHDZGU6","email":"sb-b2wrp28272214@business.example.com"},"description":"TO202305152846168177023680 : \u8d2d\u4e70\uff1a\u5929\u5361","invoice_number":"TO202305152846168177023680","item_list":{"shipping_address":{"recipient_name":"Doe John","line1":"NO 1 Nan Jin Road","city":"Shanghai","state":"Shanghai","postal_code":"200000","country_code":"C2"}},"related_resources":[]}],"intent":"sale","payer":{"payment_method":"paypal","status":"VERIFIED","payer_info":{"email":"sb-ahwqf28272209@personal.example.com","first_name":"John","last_name":"Doe","payer_id":"L8QK79HLPC3R8","shipping_address":{"recipient_name":"Doe John","line1":"NO 1 Nan Jin Road","city":"Shanghai","state":"Shanghai","postal_code":"200000","country_code":"C2"},"country_code":"C2"}},"cart":"1UG11034P27209626"},"links":[{"href":"https:\/\/api.sandbox.paypal.com\/v1\/notifications\/webhooks-events\/WH-7UH38673AN050531U-0WW4519142280404K","rel":"self","method":"GET"},{"href":"https:\/\/api.sandbox.paypal.com\/v1\/notifications\/webhooks-events\/WH-7UH38673AN050531U-0WW4519142280404K\/resend","rel":"resend","method":"POST"}],"addon":"dramas","controller":"pay","action":"notify_paypal","platform":"H5","sign":"edum"}';
//        $data = json_decode($data, true);
//        $this->success('', $data);

        if(!isset($data['resource']['transactions'][0]['invoice_number'])){
            return 'fail';
        }
        $out_trade_no = $data['resource']['transactions'][0]['invoice_number'];
        list($order, $prepay_type) = $this->getOrderInstance($out_trade_no);
        $order = $order->where('order_sn', $out_trade_no)->find();
        if (!$order || $order->status > 0) {
            // 订单不存在，或者订单已支付
            return 'success';
        }
        $paymentConfig = @json_decode(\addons\dramas\model\Config::get(['name' => 'paypal', 'site_id'=>$order['site_id']])->value, true);
        // 配置PayPal参数
        $gateway = Omnipay::create('PayPal_Rest');
        $gateway->setClientId($paymentConfig['clent_id']);
        $gateway->setSecret($paymentConfig['client_secret']);
        $mode = $paymentConfig['environment'] == 'sandbox' ? true : false;
        $gateway->setTestMode($mode); // 设置为沙箱模式，如果使用生产环境，请设置为false

        $response = $gateway->completePurchase([
            'transactionReference' => $data['resource']['id'],
            'payerId' => $data['resource']['payer']['payer_info']['payer_id'],
        ])->send();
        $isSuccessful = $response->isSuccessful();

        $amount = $data['resource']['transactions'][0]['amount']['total'];
        // $currency = $data['resource']['transactions'][0]['amount']['currency'];
        // 验证支付回调
        try {
            // 处理支付成功逻辑
            if ($isSuccessful) {
                $notify = [
                    'order_sn' => $out_trade_no,
                    'transaction_id' => $data['resource']['id'],
                    'notify_time' => date('Y-m-d H:i:s'),
                    'buyer_email' => '',
                    'payment_json' => json_encode($data),
                    'pay_fee' => $amount,
                    'pay_type' => 'paypal'              // 支付方式
                ];
                $order->paymentProcess($order, $notify);
                return 'success';
            } else {
                Log::write('notify-paypal-error:' . json_encode($response->getMessage()));
                return 'fail';
            }
        } catch (\Exception $e) {
            Log::write('notify-paypal-error:' . json_encode($e->getMessage()));
            return 'fail';
        }
    }

    /**
     * 退款成功回调
     * @ApiInternal
     */
    public function notifyr()
    {
        Log::write('notifyreturn-comein:');

        $payment = $this->request->param('payment');
        $platform = $this->request->param('platform');

        $pay = new \addons\dramas\library\PayService($this->site_id, $payment, $platform);

        $result = $pay->notifyRefund(function ($data, $pay = null) use ($payment, $platform) {
            try {
                $out_refund_no = $data['out_refund_no'];
                $out_trade_no = $data['out_trade_no'];

                // 退款逻辑


                return $this->payResponse($pay, $payment);
            } catch (\Exception $e) {
                Log::write('notifyreturn-error:' . json_encode($e->getMessage()));
                return false;
            }
        });

        return $result;
    }

    /**
     * @ApiInternal
     */
    public function confirm(){
    }

    /**
     * 响应
     * @ApiInternal
     */
    private function payResponse($pay = null, $payment = null) 
    {
        return $pay->success()->send();
    }


    /**
     * 根据订单号获取订单实例
     * @ApiInternal
     * @param [type] $order_sn
     * @return void
     */
    private function getOrderInstance($order_sn) 
    {
        if (strpos($order_sn, 'TO') === 0) {
            // VIP订单
            $prepay_type = 'vip';
            $order = new VipOrder();
        } else if (strpos($order_sn, 'AO') === 0) {
            // 剧场积分充值订单
            $prepay_type = 'usable';
            $order = new UsableOrder();
        } else {
            // 分销商订单
            $prepay_type = 'reseller';
            $order = new ResellerOrder();
        }

        return [$order, $prepay_type];
    }
}
