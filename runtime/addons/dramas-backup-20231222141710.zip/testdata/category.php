<?php

return array (
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '视频分类', 1, 'video', '', 0, 0, '', 'normal', 1689905480, 1701782680);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '战争片', 1, 'video', '', __LASTINSERTID__, 0, '战争片', 'normal', 1689905716, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '科幻片', 1, 'video', '', __LASTINSERTID__, 0, '科幻片', 'normal', 1689905716, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '偶像片', 1, 'video', '', __LASTINSERTID__, 0, '偶像片', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '武侠片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '古装片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '纪录片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '警匪片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '喜剧片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '动作片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '恐怖片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1689905818, 1701781997);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '视频年份', 1, 'year', '', 0, 0, '', 'normal', 1689905501, 1689905501);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2015', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2016', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2017', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2018', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2019', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2020', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2021', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2022', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '2023', 1, 'year', '', __LASTINSERTID__, 0, '', 'normal', 1689905956, 1689994556);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '视频地区', 1, 'area', '', 0, 0, '', 'normal', 1689905511, 1689905511);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '内地', 1, 'area', '', __LASTINSERTID__, 0, '', 'normal', 1689906006, 1689994558);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '港台', 1, 'area', '', __LASTINSERTID__, 0, '', 'normal', 1689906006, 1689994558);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '日韩', 1, 'area', '', __LASTINSERTID__, 0, '', 'normal', 1689906006, 1689994558);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '欧美', 1, 'area', '', __LASTINSERTID__, 0, '', 'normal', 1689906006, 1689994558);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 1, '其他', 1, 'area', '', __LASTINSERTID__, 0, '', 'normal', 1689906006, 1689994558);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, '英文分类', 1, 'video', '', 0, 0, '', 'normal', 1701783393, 1701783409);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'War', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Sci-fi', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Idol', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Martial arts', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Period', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Documentary', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 3, 'Action', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701783466, 1701784146);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, '泰语分类', 1, 'video', '', 0, 0, '', 'normal', 1701785023, 1701785023);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์สงคราม', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์วิทยาศาสตร์', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์ไอดอล', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์วูเอเซีย', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์โบราณ', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์แอ็คชั่น', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 5, 'ภาพยนตร์ตลก', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785584, 1701785584);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '繁体分类', 1, 'video', '', 0, 0, '', 'normal', 1701785607, 1701785607);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '戰爭片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '科幻片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '偶像片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '武俠片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '古裝片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 4, '紀錄片', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785647, 1701785647);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, '西班分类', 1, 'video', '', 0, 0, '', 'normal', 1701785790, 1701785790);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'guerra', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'ciencia ficción', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'ídolos', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'artes marciales', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'época', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'Documental', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'acción', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 7, 'comedia', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785815, 1701785870);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, '阿拉分类', 1, 'video', '', 0, 0, '', 'normal', 1701785881, 1701785881);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم حرب', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم خيال علمي', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم أيدول', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم فنون قتالية', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم تاريخي', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم وثائقي', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 8, 'فيلم كوميدي', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701785889, 1701785889);",
        ),
    "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, '越南分类', 1, 'video', '', 0, 0, '', 'normal', 1701785995, 1701785995);" =>
        array(
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'chiến tranh', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'khoa học viễn tưởng', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'idol', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'võ hiệp', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'cổ trang', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'tài liệu', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'hàiđộng', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'hài', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786030, 1701786058);",
            "INSERT INTO `__PREFIX__dramas_category` VALUES (null, __SITEID__, 9, 'hành động', 1, 'video', '', __LASTINSERTID__, 0, '', 'normal', 1701786031, 1701786058);",
        ),
);