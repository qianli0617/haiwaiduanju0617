<?php

return [
    'Lang_id'        => '语言',
    'Title'          => '标题',
    'Image'          => '图片',
    'Flag'           => '标识',
    'Desc'           => '描述',
    'Content'        => '权益',
    'Usable'         => '套餐总积分',
    'Original_usable'=> '套餐基础积分',
    'Give_usable'    => '套餐赠送积分',
    'Price'          => '价格',
    'Give_price'     => '赠送金额',
    'First_price'    => '首冲价格',
    'Original_price' => '划线价格',
    'Status'         => '是否启用',
    'Status 0'       => '不启用',
    'Status 1'       => '启用',
];
