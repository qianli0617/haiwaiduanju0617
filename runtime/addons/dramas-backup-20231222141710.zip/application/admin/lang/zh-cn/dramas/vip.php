<?php

return [
    'Lang_id'        => '语言',
    'Type'           => '充值类型',
    'Day'            => '天',
    'Month'          => '月',
    'Quarter'        => '季',
    'Year'           => '年',
    'Title'          => '标题',
    'Desc'           => '描述',
    'Content'        => '权益',
    'Price'          => '价格',
    'First_price'    => '首冲价格',
    'Original_price' => '划线价格',
    'Num'            => '充值数量',
    'Status'         => '是否启用',
    'Status 0'       => '不启用',
    'Status 1'       => '启用',
];
