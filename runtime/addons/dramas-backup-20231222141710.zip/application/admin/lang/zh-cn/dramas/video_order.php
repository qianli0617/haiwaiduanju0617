<?php

return [
    'Vid'                        => '短剧',
    'Episode_id'                 => '剧集',
    'Order_sn'                   => '订单号',
    'User_id'                    => '用户',
    'Total_fee'                  => '支付积分',
    'Platform'                   => '平台',
    'Platform h5'                => 'H5',
    'Set platform to h5'         => '设为H5',
    'Platform app'               => 'App',
    'Set platform to app'        => '设为App',
    'Video.title'                => '短剧标题',
    'Episodes.name'              => '剧集名称'
];
