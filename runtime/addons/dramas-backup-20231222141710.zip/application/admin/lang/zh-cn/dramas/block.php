<?php

return [
    'Lang_id'       => '语言',
    'Video_id'      => '视频',
    'Title'         => '标题',
    'Image'         => '图片',
    'Url'           => '链接',
    'Parsetpl'      => '链接类型',
    'Parsetpl 0'    => '外部',
    'Parsetpl 1'    => '内部',
    'Status normal' => '显示',
    'Status hidden' => '隐藏'
];
